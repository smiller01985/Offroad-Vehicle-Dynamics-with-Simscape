classdef HTMLViewer < handle
%   Run "doc matlab.htmlviewer.HTMLViewer" for more information.

%   Copyright 2021-2026 The MathWorks, Inc.

    properties (Access = public)
        Input
        Visible

    end

    properties (GetAccess = public, SetAccess = public, Hidden)
        Title
    end

    properties (GetAccess = public, SetAccess = private, Hidden)
        getCurrentLocation
        isVisible
        isShowing
        getHtmlText
    end

    properties (GetAccess = public, SetAccess = private, Hidden, SetObservable)
        IsOpen = false
    end

    properties (Access = private, Hidden)
        NewTab
        ShowToolbar
        WebHandle
        IsTextHTMLInput
        ViewerID
        RequestID
        FileName
        FilePath
        HTMLPagePath
        TextContent
        FirstPageAdded = false
    end

    properties (GetAccess = private, SetAccess = {?matlab.htmlviewer.internal.HTMLViewerManager}, Hidden)
        % When set, assignRequestID reuses this value instead of generating
        % a new UUID. Used to update page data in-place without creating a
        % duplicate navigation history entry.
        RequestIDOverride
    end

    methods
        function close(obj)
            %CLOSE  Close the HTML Viewer tab and delete the handle
            %   CLOSE(v) closes the HTML Viewer tab and deletes the handle
            %   v. If no other HTML Viewer tabs are open, CLOSE also closes
            %   the HTML Viewer.
            obj.getHTMLViewerManagerInstance().close(obj.ViewerID);
            % Invalidate viewer handle on close.
            obj.delete;
        end

        function htmlText = getHTMLText(obj)
            htmlText = string(obj.getHTMLViewerManagerInstance().getHTMLText(obj.ViewerID));
        end
    end
    % Property custom set/get implementation.
    methods
        function set.Input(obj, htmlInput)
            arguments
                obj
                htmlInput {mustBeTextScalar}
            end
            obj.Input = string(obj.getHTMLViewerManagerInstance().validateInput(htmlInput));
            obj.updateHTMLViewer();
        end
        function set.Title(obj, htmlTitle)
            arguments
                obj
                htmlTitle (1,1) string {mustBeTextScalar} = ""
            end
            obj.Title = htmlTitle;
            obj.getHTMLViewerManagerInstance().setTitle(obj.ViewerID, htmlTitle); %#ok<MCSUP>
        end
        function title = get.Title(obj)
            title = string(obj.getHTMLViewerManagerInstance().getTitle(obj.ViewerID));
        end

        function visible = get.Visible(obj)
            visible = obj.Visible;
        end

        function set.Visible(obj, value)
            arguments
                obj
                value (1,1) logical {mustBeNumericOrLogical}
            end
            obj.Visible = value;
            obj.getHTMLViewerManagerInstance().setVisibility(obj.ViewerID, value); %#ok<MCSUP>
        end
        % The below methods are added for pass-through from web to
        % HTMLViewer
        function loc = get.getCurrentLocation(obj)
            loc = obj.Input;
        end

        function visible = get.isVisible(obj)
            visible = obj.Visible;
        end

        function isShown = get.isShowing(obj)
            isShown = isequal(obj,matlab.htmlviewer.internal.getActiveWindow());
        end

        function html = get.getHtmlText(obj)
            html = obj.getHTMLText;
        end
    end

    methods(Hidden)
        % The below methods are added for pass-through from web to
        % HTMLViewer
        function hide(obj)
            obj.Visible = 0;
        end

        function show(obj)
            obj.Visible = 1;
        end

        function setHtmlText(obj, htmlInput)
            obj.Input = htmlInput;
        end

        function setCurrentLocation(obj, location)
            obj.Input = location;
        end

        function requestFocus(obj)
            obj.Visible = true;
        end
    end

    methods(Static, Hidden)
        function htmlManagerInstance = getHTMLViewerManagerInstance()
            htmlManagerInstance =  matlab.htmlviewer.internal.HTMLViewerManager.getInstance();
        end
    end 
    methods (Hidden)
        function obj = HTMLViewer(options)
            obj.parseInputs(options);
        end

        function open(obj)
            payload = struct(...
                'ViewerID', obj.ViewerID, ...
                'RequestID', obj.RequestID, ...
                'Input', obj.Input, ...
                'FileName', obj.FileName, ...
                'FilePath', obj.FilePath, ...
                'HTMLPagePath', obj.HTMLPagePath, ...
                'NewTab', obj.NewTab, ...
                'ShowToolbar', obj.ShowToolbar, ...
                'IsTextHTMLInput', obj.IsTextHTMLInput, ...
                'TextContent', obj.TextContent);
            % g4481410 workaround - send the static path percent-encoded so it matches the
            % iframe's location.pathname, else the UI sees a redirect and reloads forever.
            payload.HTMLPagePath = encodeStaticPagePath(obj.HTMLPagePath, obj.FileName);
            obj.getHTMLViewerManagerInstance().requestHTMLPageOpen(payload);
            obj.updateOnOpen();
        end

        function updateInputArguments(obj, options)
            options.ViewerID = obj.ViewerID;
            obj.parseInputs(options);
        end

        function status = isTabOpen(obj)
            status = obj.IsOpen;
        end
    end

    methods (Access = private)
        function parseInputs(obj, options)
            obj.ViewerID = options.ViewerID;
            obj.RequestID = options.RequestID;
            obj.NewTab = options.NewTab;
            obj.ShowToolbar = options.ShowToolbar;
            % more properties will be assigned through set.Input method
        end

        function updateHTMLViewer(obj)
            htmlViewerInstance = obj.getHTMLViewerManagerInstance();
            % For text:// content, 'FileName', 'HTMLPagePath' and 'FilePath' are empty strings.
            % For .txt files, 'HTMLPagePath' is empty string.
            % For .htm or .html files, 'TextContent' is empty string, 'HTMLPagePath' will hold static file path.
            % For https://localhost:... links, 'HTMLPagePath' will hold the original Input string, 'TextContent' & 'FilePath' will be empty strings.
            [obj.FileName, obj.HTMLPagePath, obj.IsTextHTMLInput, obj.TextContent, obj.FilePath] = htmlViewerInstance.addHTMLPageLocationToSecureList(obj.Input);
            obj.assignRequestID();
            obj.open();
        end
        
        function assignRequestID(obj)
            % Two flows set RequestIDOverride:
            % 1. Frontend redirect — reuses RequestID to update history in-place.
            % 2. Empty first page (web command) — holds RequestID so the
            %    next real page replaces the blank entry.
            if ~isempty(obj.RequestIDOverride)
                obj.RequestID = obj.RequestIDOverride;
                obj.RequestIDOverride = [];
                return;
            end
            if ~obj.FirstPageAdded && obj.getHTMLViewerManagerInstance().isInputBlank(obj.Input)
                obj.RequestID = string(obj.getHTMLViewerManagerInstance().createUUID());
                obj.RequestIDOverride = obj.RequestID;
            else
                obj.RequestID = string(obj.getHTMLViewerManagerInstance().createUUID());
            end
            obj.FirstPageAdded = true;
        end

        function updateOnOpen(obj)
            obj.Visible = true;
            obj.IsOpen = true;
            obj.NewTab = false; % Set the NewTab flag to indicate any further request from this viewer will not create a new tab. %/
        end
    end
end

function pagePath = encodeStaticPagePath(pagePath, fileName)
    % Leave text:// (empty) and localhost URL inputs untouched.
    pagePath = string(pagePath);
    if strlength(pagePath) == 0 || startsWith(pagePath, ["http:", "https:"], 'IgnoreCase', true)
        return
    end
    % Keep the #anchor/?query tail raw; it is carried on FileName.
    tail = extract(string(fileName), regexpPattern("[#?].*"));
    if isempty(tail) || ~endsWith(pagePath, tail)
        tail = "";
    end
    pathPart = extractBefore(pagePath, strlength(pagePath) - strlength(tail) + 1);
    % Encode all but unreserved chars and '/'. Browsers keep existing %XX escapes,
    % so location.pathname comes back identical.
    bytes = unicode2native(char(pathPart), 'UTF-8');
    isKept = (isstrprop(char(bytes), 'alphanum') & bytes < 128) | ismember(bytes, uint8('-._~/'));
    parts = string(num2cell(char(bytes)));
    parts(~isKept) = compose("%%%02X", double(bytes(~isKept)));
    pagePath = join([parts, ""], "") + tail;
end
